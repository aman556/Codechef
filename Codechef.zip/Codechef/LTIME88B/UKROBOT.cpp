#include <iostream>
using namespace std;

int main() {
	// your code goes here
	int r,c;
	cin>>r>>c;
	cout<<"U";
	for(int i=1;i<c;i++)
	    cout<<"R";
	    cout<<endl;
	return 0;
}
